import axios from "axios";

const API_URL = import.meta.env.VITE_API_URL || "http://localhost:5000/api";

const api = axios.create({
  baseURL: API_URL,
});

// Attach the JWT token (if present) to every outgoing request
api.interceptors.request.use((config) => {
  const userInfo = localStorage.getItem("userInfo");
  if (userInfo) {
    const { token } = JSON.parse(userInfo);
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
  }
  return config;
});

// Auth
export const registerUser = (data) => api.post("/auth/register", data);
export const loginUser = (data) => api.post("/auth/login", data);

// Products
export const fetchProducts = (params) => api.get("/products", { params });
export const fetchProductById = (id) => api.get(`/products/${id}`);
export const createProduct = (data) => api.post("/products", data);
export const updateProduct = (id, data) => api.put(`/products/${id}`, data);
export const deleteProduct = (id) => api.delete(`/products/${id}`);

// Cart
export const fetchCart = () => api.get("/cart");
export const addToCartApi = (data) => api.post("/cart", data);
export const updateCartItemApi = (productId, data) =>
  api.put(`/cart/${productId}`, data);
export const removeCartItemApi = (productId) => api.delete(`/cart/${productId}`);

// Orders
export const createOrder = (data) => api.post("/orders", data);
export const fetchMyOrders = () => api.get("/orders/myorders");
export const fetchAllOrders = () => api.get("/orders");
export const updateOrderStatusApi = (id, status) =>
  api.put(`/orders/${id}/status`, { status });

// Users
export const fetchUsers = () => api.get("/users");

export default api;
