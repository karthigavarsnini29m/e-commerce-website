import { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";
import { fetchMyOrders } from "../services/api";
import Loader from "../components/Loader";

const statusColors = {
  Pending: "status-pending",
  Confirmed: "status-confirmed",
  Shipped: "status-shipped",
  Delivered: "status-delivered",
  Cancelled: "status-cancelled",
};

const MyOrders = () => {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const location = useLocation();

  useEffect(() => {
    const loadOrders = async () => {
      try {
        setLoading(true);
        const { data } = await fetchMyOrders();
        setOrders(data);
      } catch (err) {
        setError(err.response?.data?.message || "Failed to load orders");
      } finally {
        setLoading(false);
      }
    };
    loadOrders();
  }, []);

  if (loading) return <Loader />;

  return (
    <div className="orders-page">
      <h1>My Orders</h1>
      {location.state?.orderPlaced && (
        <p className="success-message">Order placed successfully!</p>
      )}
      {error && <p className="error-message">{error}</p>}

      {!error && orders.length === 0 && (
        <p className="empty-state">You haven't placed any orders yet.</p>
      )}

      <div className="orders-list">
        {orders.map((order) => (
          <div key={order._id} className="order-card">
            <div className="order-card-header">
              <div>
                <strong>Order ID:</strong> {order._id}
                <br />
                <strong>Date:</strong> {new Date(order.createdAt).toLocaleDateString()}
              </div>
              <span className={`status-badge ${statusColors[order.status]}`}>
                {order.status}
              </span>
            </div>

            <div className="order-card-products">
              {order.products.map((p, idx) => (
                <div key={idx} className="order-product-row">
                  <img src={p.image} alt={p.name} />
                  <span>
                    {p.name} × {p.quantity}
                  </span>
                  <span>₹{p.price * p.quantity}</span>
                </div>
              ))}
            </div>

            <div className="order-card-footer">
              <div>
                <strong>Delivery Address:</strong>{" "}
                {order.shippingAddress.address}, {order.shippingAddress.city},{" "}
                {order.shippingAddress.state} - {order.shippingAddress.pincode}
              </div>
              <div className="order-total">Total: ₹{order.totalAmount}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default MyOrders;
