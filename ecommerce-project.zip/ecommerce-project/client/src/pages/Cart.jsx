import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useCart } from "../context/CartContext";
import Loader from "../components/Loader";

const Cart = () => {
  const { cart, loading, loadCart, updateQuantity, removeItem, subtotal, itemCount } = useCart();
  const [error, setError] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    loadCart();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleIncrease = async (item) => {
    setError("");
    try {
      if (item.quantity + 1 > item.product.stock) {
        setError(`Only ${item.product.stock} units of ${item.product.name} available`);
        return;
      }
      await updateQuantity(item.product._id, item.quantity + 1);
    } catch (err) {
      setError(err.response?.data?.message || "Could not update quantity");
    }
  };

  const handleDecrease = async (item) => {
    setError("");
    if (item.quantity <= 1) return;
    try {
      await updateQuantity(item.product._id, item.quantity - 1);
    } catch (err) {
      setError(err.response?.data?.message || "Could not update quantity");
    }
  };

  const handleRemove = async (item) => {
    setError("");
    try {
      await removeItem(item.product._id);
    } catch (err) {
      setError(err.response?.data?.message || "Could not remove item");
    }
  };

  if (loading) return <Loader />;

  const items = cart.items || [];

  return (
    <div className="cart-page">
      <h1>Shopping Cart</h1>
      {error && <p className="error-message">{error}</p>}

      {items.length === 0 ? (
        <div className="empty-state">
          <p>Your cart is empty.</p>
          <Link to="/products" className="btn-primary">
            Browse Products
          </Link>
        </div>
      ) : (
        <div className="cart-layout">
          <div className="cart-items">
            {items.map((item) => (
              <div key={item.product._id} className="cart-item">
                <img src={item.product.image} alt={item.product.name} />
                <div className="cart-item-info">
                  <h3>{item.product.name}</h3>
                  <p>₹{item.product.price} each</p>
                </div>
                <div className="cart-item-qty">
                  <button onClick={() => handleDecrease(item)}>-</button>
                  <span>{item.quantity}</span>
                  <button onClick={() => handleIncrease(item)}>+</button>
                </div>
                <div className="cart-item-total">₹{item.product.price * item.quantity}</div>
                <button className="btn-remove" onClick={() => handleRemove(item)}>
                  Remove
                </button>
              </div>
            ))}
          </div>

          <div className="cart-summary">
            <h2>Order Summary</h2>
            <div className="summary-row">
              <span>Total Items</span>
              <span>{itemCount}</span>
            </div>
            <div className="summary-row">
              <span>Subtotal</span>
              <span>₹{subtotal}</span>
            </div>
            <div className="summary-row total">
              <span>Total</span>
              <span>₹{subtotal}</span>
            </div>
            <button className="btn-primary" onClick={() => navigate("/checkout")}>
              Proceed to Checkout
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default Cart;
