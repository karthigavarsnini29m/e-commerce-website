import { useEffect, useState } from "react";
import {
  fetchProducts,
  createProduct,
  updateProduct,
  deleteProduct,
} from "../../services/api";
import Loader from "../../components/Loader";

const emptyForm = {
  name: "",
  description: "",
  price: "",
  category: "",
  image: "",
  stock: "",
};

const AdminProducts = () => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const [form, setForm] = useState(emptyForm);
  const [editingId, setEditingId] = useState(null);
  const [showForm, setShowForm] = useState(false);

  const loadProducts = async () => {
    try {
      setLoading(true);
      const { data } = await fetchProducts({});
      setProducts(data);
    } catch (err) {
      setError("Failed to load products");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadProducts();
  }, []);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const resetForm = () => {
    setForm(emptyForm);
    setEditingId(null);
    setShowForm(false);
  };

  const handleEdit = (product) => {
    setForm({
      name: product.name,
      description: product.description,
      price: product.price,
      category: product.category,
      image: product.image,
      stock: product.stock,
    });
    setEditingId(product._id);
    setShowForm(true);
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Are you sure you want to delete this product?")) return;
    setError("");
    setMessage("");
    try {
      await deleteProduct(id);
      setMessage("Product deleted successfully");
      loadProducts();
    } catch (err) {
      setError(err.response?.data?.message || "Failed to delete product");
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setMessage("");

    const { name, description, price, category, image, stock } = form;
    if (!name || !description || !price || !category || !image || stock === "") {
      setError("All fields are required");
      return;
    }

    const payload = {
      name,
      description,
      price: Number(price),
      category,
      image,
      stock: Number(stock),
    };

    try {
      if (editingId) {
        await updateProduct(editingId, payload);
        setMessage("Product updated successfully");
      } else {
        await createProduct(payload);
        setMessage("Product created successfully");
      }
      resetForm();
      loadProducts();
    } catch (err) {
      setError(err.response?.data?.message || "Failed to save product");
    }
  };

  return (
    <div>
      <div className="section-header">
        <h1>Manage Products</h1>
        <button className="btn-primary" onClick={() => (showForm ? resetForm() : setShowForm(true))}>
          {showForm ? "Cancel" : "+ Add Product"}
        </button>
      </div>

      {error && <p className="error-message">{error}</p>}
      {message && <p className="success-message">{message}</p>}

      {showForm && (
        <form className="admin-form" onSubmit={handleSubmit}>
          <div className="form-row">
            <div>
              <label>Name</label>
              <input name="name" value={form.name} onChange={handleChange} />
            </div>
            <div>
              <label>Category</label>
              <input name="category" value={form.category} onChange={handleChange} />
            </div>
          </div>
          <label>Description</label>
          <textarea name="description" value={form.description} onChange={handleChange} />
          <div className="form-row">
            <div>
              <label>Price (₹)</label>
              <input type="number" name="price" value={form.price} onChange={handleChange} />
            </div>
            <div>
              <label>Stock</label>
              <input type="number" name="stock" value={form.stock} onChange={handleChange} />
            </div>
          </div>
          <label>Image URL</label>
          <input name="image" value={form.image} onChange={handleChange} />

          <button type="submit" className="btn-primary">
            {editingId ? "Update Product" : "Create Product"}
          </button>
        </form>
      )}

      {loading ? (
        <Loader />
      ) : (
        <table className="admin-table">
          <thead>
            <tr>
              <th>Image</th>
              <th>Name</th>
              <th>Category</th>
              <th>Price</th>
              <th>Stock</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {products.map((p) => (
              <tr key={p._id}>
                <td>
                  <img src={p.image} alt={p.name} className="admin-table-img" />
                </td>
                <td>{p.name}</td>
                <td>{p.category}</td>
                <td>₹{p.price}</td>
                <td>{p.stock}</td>
                <td>
                  <button className="btn-link" onClick={() => handleEdit(p)}>
                    Edit
                  </button>
                  <button className="btn-link btn-danger" onClick={() => handleDelete(p._id)}>
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default AdminProducts;
