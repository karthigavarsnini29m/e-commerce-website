import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { fetchProductById } from "../services/api";
import { useAuth } from "../context/AuthContext";
import { useCart } from "../context/CartContext";
import Loader from "../components/Loader";

const ProductDetails = () => {
  const { id } = useParams();
  const [product, setProduct] = useState(null);
  const [quantity, setQuantity] = useState(1);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const { userInfo } = useAuth();
  const { addToCart } = useCart();
  const navigate = useNavigate();

  useEffect(() => {
    const loadProduct = async () => {
      try {
        setLoading(true);
        setError("");
        const { data } = await fetchProductById(id);
        setProduct(data);
      } catch (err) {
        setError(err.response?.data?.message || "Product not found");
      } finally {
        setLoading(false);
      }
    };
    loadProduct();
  }, [id]);

  const handleAddToCart = async () => {
    if (!userInfo) {
      navigate("/login");
      return;
    }
    setError("");
    setMessage("");
    try {
      await addToCart(product._id, quantity);
      setMessage("Added to cart!");
    } catch (err) {
      setError(err.response?.data?.message || "Could not add to cart");
    }
  };

  if (loading) return <Loader />;
  if (error && !product) return <p className="error-message">{error}</p>;
  if (!product) return null;

  return (
    <div className="product-details-page">
      <div className="product-details-image">
        <img src={product.image} alt={product.name} />
      </div>
      <div className="product-details-info">
        <span className="product-card-category">{product.category}</span>
        <h1>{product.name}</h1>
        <p className="product-details-price">₹{product.price}</p>
        <p className="product-details-description">{product.description}</p>
        <p className={`stock-tag ${product.stock === 0 ? "out" : ""}`}>
          {product.stock === 0 ? "Out of stock" : `${product.stock} in stock`}
        </p>

        {error && <p className="error-message">{error}</p>}
        {message && <p className="success-message">{message}</p>}

        {product.stock > 0 && (
          <div className="quantity-selector">
            <label>Quantity:</label>
            <select value={quantity} onChange={(e) => setQuantity(Number(e.target.value))}>
              {Array.from({ length: Math.min(product.stock, 10) }, (_, i) => i + 1).map((n) => (
                <option key={n} value={n}>
                  {n}
                </option>
              ))}
            </select>
          </div>
        )}

        <button
          className="btn-primary"
          disabled={product.stock === 0}
          onClick={handleAddToCart}
        >
          {product.stock === 0 ? "Out of Stock" : "Add to Cart"}
        </button>
      </div>
    </div>
  );
};

export default ProductDetails;
