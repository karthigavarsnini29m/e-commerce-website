import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useCart } from "../context/CartContext";
import { createOrder } from "../services/api";

const Checkout = () => {
  const { cart, subtotal, clearCartLocal } = useCart();
  const [form, setForm] = useState({
    fullName: "",
    phone: "",
    address: "",
    city: "",
    state: "",
    pincode: "",
  });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const items = cart.items || [];

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");

    const { fullName, phone, address, city, state, pincode } = form;
    if (!fullName || !phone || !address || !city || !state || !pincode) {
      setError("Please fill in all delivery details");
      return;
    }

    if (items.length === 0) {
      setError("Your cart is empty");
      return;
    }

    try {
      setLoading(true);
      const orderPayload = {
        products: items.map((item) => ({
          productId: item.product._id,
          quantity: item.quantity,
        })),
        shippingAddress: form,
      };
      const { data } = await createOrder(orderPayload);
      clearCartLocal();
      navigate("/my-orders", { state: { orderPlaced: true, orderId: data._id } });
    } catch (err) {
      setError(err.response?.data?.message || "Failed to place order. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  if (items.length === 0) {
    return (
      <div className="checkout-page">
        <p className="empty-state">Your cart is empty. Add some products before checking out.</p>
      </div>
    );
  }

  return (
    <div className="checkout-page">
      <h1>Checkout</h1>
      <div className="checkout-layout">
        <form className="checkout-form" onSubmit={handleSubmit}>
          <h2>Delivery Details</h2>
          {error && <p className="error-message">{error}</p>}

          <label>Customer Name</label>
          <input name="fullName" value={form.fullName} onChange={handleChange} />

          <label>Phone Number</label>
          <input name="phone" value={form.phone} onChange={handleChange} />

          <label>Delivery Address</label>
          <input name="address" value={form.address} onChange={handleChange} />

          <div className="form-row">
            <div>
              <label>City</label>
              <input name="city" value={form.city} onChange={handleChange} />
            </div>
            <div>
              <label>State</label>
              <input name="state" value={form.state} onChange={handleChange} />
            </div>
          </div>

          <label>Pincode</label>
          <input name="pincode" value={form.pincode} onChange={handleChange} />

          <button type="submit" className="btn-primary" disabled={loading}>
            {loading ? "Placing Order..." : "Place Order"}
          </button>
        </form>

        <div className="cart-summary">
          <h2>Order Summary</h2>
          {items.map((item) => (
            <div key={item.product._id} className="summary-row">
              <span>
                {item.product.name} × {item.quantity}
              </span>
              <span>₹{item.product.price * item.quantity}</span>
            </div>
          ))}
          <div className="summary-row total">
            <span>Total Amount</span>
            <span>₹{subtotal}</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Checkout;
