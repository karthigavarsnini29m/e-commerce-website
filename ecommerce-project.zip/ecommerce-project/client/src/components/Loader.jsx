const Loader = () => (
  <div className="loader-container">
    <div className="loader-spinner"></div>
    <p>Loading...</p>
  </div>
);

export default Loader;
