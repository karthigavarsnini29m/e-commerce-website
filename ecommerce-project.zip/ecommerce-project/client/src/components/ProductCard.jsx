import { Link } from "react-router-dom";

const ProductCard = ({ product }) => {
  return (
    <div className="product-card">
      <Link to={`/products/${product._id}`}>
        <img src={product.image} alt={product.name} className="product-card-img" />
      </Link>
      <div className="product-card-body">
        <span className="product-card-category">{product.category}</span>
        <Link to={`/products/${product._id}`}>
          <h3 className="product-card-title">{product.name}</h3>
        </Link>
        <div className="product-card-footer">
          <span className="product-card-price">₹{product.price}</span>
          <span className={`stock-tag ${product.stock === 0 ? "out" : ""}`}>
            {product.stock === 0 ? "Out of stock" : `${product.stock} in stock`}
          </span>
        </div>
      </div>
    </div>
  );
};

export default ProductCard;
