import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { useCart } from "../context/CartContext";

const Navbar = () => {
  const { userInfo, logout } = useAuth();
  const { itemCount } = useCart();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  return (
    <header className="navbar">
      <div className="navbar-container">
        <Link to="/" className="navbar-brand">
          ShopEase
        </Link>

        <nav className="navbar-links">
          <Link to="/">Home</Link>
          <Link to="/products">Products</Link>
          <Link to="/cart">Cart {itemCount > 0 && <span className="badge">{itemCount}</span>}</Link>
          {userInfo && <Link to="/my-orders">My Orders</Link>}
          {userInfo?.role === "admin" && <Link to="/admin">Admin</Link>}

          {userInfo ? (
            <div className="navbar-user">
              <span>Hi, {userInfo.name.split(" ")[0]}</span>
              <button className="btn-link" onClick={handleLogout}>
                Logout
              </button>
            </div>
          ) : (
            <Link to="/login">Login/Register</Link>
          )}
        </nav>
      </div>
    </header>
  );
};

export default Navbar;
