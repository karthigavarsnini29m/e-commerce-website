import { createContext, useContext, useState, useCallback } from "react";
import {
  fetchCart,
  addToCartApi,
  updateCartItemApi,
  removeCartItemApi,
} from "../services/api";
import { useAuth } from "./AuthContext";

const CartContext = createContext();

export const CartProvider = ({ children }) => {
  const { userInfo } = useAuth();
  const [cart, setCart] = useState({ items: [] });
  const [loading, setLoading] = useState(false);

  const loadCart = useCallback(async () => {
    if (!userInfo) return;
    setLoading(true);
    try {
      const { data } = await fetchCart();
      setCart(data);
    } catch (error) {
      console.error("Failed to load cart:", error);
    } finally {
      setLoading(false);
    }
  }, [userInfo]);

  const addToCart = async (productId, quantity = 1) => {
    const { data } = await addToCartApi({ productId, quantity });
    setCart(data);
    return data;
  };

  const updateQuantity = async (productId, quantity) => {
    const { data } = await updateCartItemApi(productId, { quantity });
    setCart(data);
    return data;
  };

  const removeItem = async (productId) => {
    const { data } = await removeCartItemApi(productId);
    setCart(data);
    return data;
  };

  const clearCartLocal = () => setCart({ items: [] });

  const itemCount = cart.items?.reduce((sum, item) => sum + item.quantity, 0) || 0;
  const subtotal =
    cart.items?.reduce(
      (sum, item) => sum + (item.product?.price || 0) * item.quantity,
      0
    ) || 0;

  return (
    <CartContext.Provider
      value={{
        cart,
        loading,
        loadCart,
        addToCart,
        updateQuantity,
        removeItem,
        clearCartLocal,
        itemCount,
        subtotal,
      }}
    >
      {children}
    </CartContext.Provider>
  );
};

export const useCart = () => useContext(CartContext);
