require("dotenv").config();
const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const connectDB = require("./config/db");
const User = require("./models/User");
const Product = require("./models/Product");
const Order = require("./models/Order");
const Cart = require("./models/Cart");

const products = [
  {
    name: "Wireless Bluetooth Headphones",
    description: "Over-ear headphones with active noise cancellation and 30-hour battery life.",
    price: 2999,
    category: "Electronics",
    image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=500",
    stock: 25,
  },
  {
    name: "Smartwatch Series 5",
    description: "Fitness tracking smartwatch with heart rate monitor and GPS.",
    price: 4999,
    category: "Electronics",
    image: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=500",
    stock: 15,
  },
  {
    name: "Portable Bluetooth Speaker",
    description: "Waterproof portable speaker with rich bass and 12-hour playtime.",
    price: 1799,
    category: "Electronics",
    image: "https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?w=500",
    stock: 30,
  },
  {
    name: "Men's Casual Shirt",
    description: "Slim-fit cotton casual shirt, breathable and comfortable for all-day wear.",
    price: 899,
    category: "Fashion",
    image: "https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?w=500",
    stock: 50,
  },
  {
    name: "Women's Summer Dress",
    description: "Lightweight floral summer dress, perfect for casual outings.",
    price: 1299,
    category: "Fashion",
    image: "https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=500",
    stock: 40,
  },
  {
    name: "Denim Jacket",
    description: "Classic unisex denim jacket with a modern relaxed fit.",
    price: 1999,
    category: "Fashion",
    image: "https://images.unsplash.com/photo-1544022613-e87ca75a784a?w=500",
    stock: 20,
  },
  {
    name: "Running Shoes",
    description: "Lightweight running shoes with breathable mesh upper and cushioned sole.",
    price: 2499,
    category: "Shoes",
    image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=500",
    stock: 35,
  },
  {
    name: "Leather Formal Shoes",
    description: "Genuine leather formal shoes, ideal for office and formal occasions.",
    price: 3499,
    category: "Shoes",
    image: "https://images.unsplash.com/photo-1614252369475-531eba835eb1?w=500",
    stock: 18,
  },
  {
    name: "Canvas Sneakers",
    description: "Casual canvas sneakers with a comfortable rubber sole.",
    price: 1499,
    category: "Shoes",
    image: "https://images.unsplash.com/photo-1525966222134-fcfa99b8ae77?w=500",
    stock: 45,
  },
  {
    name: "Leather Wallet",
    description: "Genuine leather bifold wallet with multiple card slots.",
    price: 799,
    category: "Accessories",
    image: "https://images.unsplash.com/photo-1627123424574-724758594e93?w=500",
    stock: 60,
  },
  {
    name: "Aviator Sunglasses",
    description: "UV-protected aviator sunglasses with a metal frame.",
    price: 999,
    category: "Accessories",
    image: "https://images.unsplash.com/photo-1572635196237-14b3f281503f?w=500",
    stock: 40,
  },
  {
    name: "Analog Wrist Watch",
    description: "Elegant analog wrist watch with a stainless steel strap.",
    price: 2299,
    category: "Accessories",
    image: "https://images.unsplash.com/photo-1524592094714-0f0654e20314?w=500",
    stock: 22,
  },
  {
    name: "Non-Stick Cookware Set",
    description: "5-piece non-stick cookware set, dishwasher safe.",
    price: 3299,
    category: "Home",
    image: "https://images.unsplash.com/photo-1584990347449-a5d9f800a783?w=500",
    stock: 12,
  },
  {
    name: "LED Table Lamp",
    description: "Adjustable LED table lamp with touch control and 3 brightness modes.",
    price: 1199,
    category: "Home",
    image: "https://images.unsplash.com/photo-1507473885765-e6ed057f782c?w=500",
    stock: 28,
  },
  {
    name: "Cotton Bedsheet Set",
    description: "Premium cotton bedsheet set with 2 pillow covers, queen size.",
    price: 1599,
    category: "Home",
    image: "https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?w=500",
    stock: 24,
  },
  {
    name: "Organic Face Moisturizer",
    description: "Lightweight, non-greasy face moisturizer with aloe vera and vitamin E.",
    price: 549,
    category: "Beauty",
    image: "https://images.unsplash.com/photo-1556228720-195a672e8a03?w=500",
    stock: 55,
  },
  {
    name: "Matte Lipstick Set",
    description: "Set of 4 long-lasting matte lipsticks in versatile shades.",
    price: 699,
    category: "Beauty",
    image: "https://images.unsplash.com/photo-1586495777744-4413f21062fa?w=500",
    stock: 38,
  },
  {
    name: "Hair Dryer",
    description: "Compact hair dryer with 2 heat settings and cool-shot button.",
    price: 1399,
    category: "Beauty",
    image: "https://images.unsplash.com/photo-1522338242992-e1a54906a8da?w=500",
    stock: 20,
  },
];

const importData = async () => {
  try {
    await connectDB();

    // Clear existing data
    await Product.deleteMany();
    await Order.deleteMany();
    await Cart.deleteMany();
    await User.deleteMany();

    // Create admin user
    const salt = await bcrypt.genSalt(10);
    const adminPassword = await bcrypt.hash("admin123", salt);

    await User.create({
      name: "Admin User",
      email: "admin@example.com",
      password: adminPassword,
      role: "admin",
    });

    // Create a sample regular user
    const userPassword = await bcrypt.hash("user123", salt);
    await User.create({
      name: "Test User",
      email: "user@example.com",
      password: userPassword,
      role: "user",
    });

    // Insert products
    await Product.insertMany(products);

    console.log("=================================");
    console.log("Data imported successfully!");
    console.log(`${products.length} products created`);
    console.log("Admin login: admin@example.com / admin123");
    console.log("User login:  user@example.com / user123");
    console.log("=================================");

    process.exit();
  } catch (error) {
    console.error(`Error: ${error.message}`);
    process.exit(1);
  }
};

const destroyData = async () => {
  try {
    await connectDB();
    await Product.deleteMany();
    await Order.deleteMany();
    await Cart.deleteMany();
    await User.deleteMany();
    console.log("Data destroyed!");
    process.exit();
  } catch (error) {
    console.error(`Error: ${error.message}`);
    process.exit(1);
  }
};

if (process.argv[2] === "-d") {
  destroyData();
} else {
  importData();
}
