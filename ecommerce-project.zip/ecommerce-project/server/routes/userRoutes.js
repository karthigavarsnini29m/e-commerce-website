const express = require("express");
const router = express.Router();
const { getUsers } = require("../controllers/userController");
const { protect } = require("../middleware/auth");
const { admin } = require("../middleware/admin");

router.get("/", protect, admin, getUsers);

module.exports = router;
